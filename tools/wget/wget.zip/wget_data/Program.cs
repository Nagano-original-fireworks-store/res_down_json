﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

class Program
{
    private const string OutputFormat = "{0}|{1}|{2}|{3}";
    private const string JsonFilePath = "info_data_versions.json";

    public static async Task Main()
    {
        if (!File.Exists(JsonFilePath))
        {
            Console.WriteLine($"File {JsonFilePath} not found.");
            return;
        }

        var jsonData = await File.ReadAllTextAsync(JsonFilePath);
        var versions = JsonSerializer.Deserialize<Dictionary<string, VersionData>>(jsonData);

        using var writer = new StreamWriter("output.txt", false, Encoding.UTF8);
        foreach (var version in versions)
        {
            await ProcessUrl(version.Key, version.Value.Version_Suffix_client, "client", writer);
            await ProcessUrl(version.Key, version.Value.Version_Suffix_silence, "client_silence", writer);
        }
    }

    private static async Task ProcessUrl(string version, string versionSuffix, string type, StreamWriter writer)
    {
        var constructedUrl = $"https://autopatchcn.yuanshen.com/client_design_data/{version}_live/output_{versionSuffix}/{type}/General/AssetBundles/data_versions";
        try
        {
            Console.WriteLine($"Processing: {constructedUrl}");

            using var client = new HttpClient();
            var data = await client.GetByteArrayAsync(constructedUrl);

            var md5 = CalculateMD5(data);
            var size = data.Length;

            var outputLine = string.Format(OutputFormat, version, type, md5, size);
            await writer.WriteLineAsync(outputLine);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error processing {constructedUrl}: {ex.Message}");
        }
    }

    private static string CalculateMD5(byte[] data)
    {
        using var md5 = MD5.Create();
        var hash = md5.ComputeHash(data);
        return BitConverter.ToString(hash).Replace("-", "").ToLower();
    }

    public class VersionData
    {
        public string Version_Suffix_client { get; set; }
        public string Version_Suffix_silence { get; set; }
    }
}
