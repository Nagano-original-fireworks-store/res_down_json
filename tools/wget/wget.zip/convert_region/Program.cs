﻿using System;
using System.IO;
using Newtonsoft.Json.Linq;

namespace JsonConverterApp
{
    class Program
    {
        static void Main(string[] args)
        {
            string inputDirectory = "./input";
            string outputDirectory = "./output";

            // Check and create input directory if it does not exist
            if (!Directory.Exists(inputDirectory))
            {
                Console.WriteLine($"Input directory {inputDirectory} does not exist. Creating it...");
                Directory.CreateDirectory(inputDirectory);
            }

            // Check and create output directory if it does not exist
            if (!Directory.Exists(outputDirectory))
            {
                Console.WriteLine($"Output directory {outputDirectory} does not exist. Creating it...");
                Directory.CreateDirectory(outputDirectory);
            }

            var files = Directory.GetFiles(inputDirectory, "*.json");
            if (files.Length == 0)
            {
                Console.WriteLine("No JSON files found in the input directory.");
                return;
            }

            foreach (var filePath in files)
            {
                Console.WriteLine($"Processing {filePath}...");
                string oldData = File.ReadAllText(filePath);
                JObject oldJson = JObject.Parse(oldData) ?? new JObject();
                JObject newJson = ConvertOldToNew(oldJson);
                string newFilePath = Path.Combine(outputDirectory, Path.GetFileName(filePath));
                File.WriteAllText(newFilePath, newJson.ToString());
                Console.WriteLine($"File has been successfully converted and saved to {newFilePath}");
            }

            Console.WriteLine("All files processed.");
        }

        static JObject ConvertOldToNew(JObject oldJson)
        {
            // Ensure "region_info" exists
            var regionInfo = oldJson["region_info"] as JObject ?? new JObject();

            JObject newJson = new JObject
            {
                ["regionInfo"] = new JObject
                {
                    ["PayCallbackUrl"] = "http://127.0.0.1/pay-callback",
                    ["AreaType"] = regionInfo?["area_type"]?.ToString() ?? "",
                    ["CdkeyUrl"] = "http://127.0.0.1",
                    ["PrivacyPolicyUrl"] = "",
                    ["FeedbackUrl"] = "",
                    ["BulletinUrl"] = "",
                    ["SecretKey"] = "",
                    ["ResourceUrl"] = regionInfo?["resource_url"]?.ToString() ?? "",
                    ["DataUrl"] = regionInfo?["data_url"]?.ToString() ?? "",
                    ["ResourceUrlBak"] = regionInfo?["resource_url_bak"]?.ToString() ?? "",
                    ["DataUrlBak"] = regionInfo?["resource_url_bak"]?.ToString() ?? "",
                    ["ClientDataVersion"] = regionInfo?["client_data_version"],
                    ["ClientSilenceDataVersion"] = regionInfo?["client_silence_data_version"],
                    ["ClientDataMd5"] = regionInfo?["client_data_md5"]?.ToString() ?? "",
                    ["ClientSilenceDataMd5"] = regionInfo?["client_silence_data_md5"]?.ToString() ?? "",
                    ["ClientVersionSuffix"] = regionInfo?["client_version_suffix"]?.ToString() ?? "",
                    ["ClientSilenceVersionSuffix"] = regionInfo?["client_silence_version_suffix"]?.ToString() ?? "",
                    ["ResVersionConfig"] = new JObject
                    {
                        ["Relogin"] = false,
                        ["Md5"] = regionInfo?["res_version_config"]?["md5"]?.ToString() ?? "",
                        ["Version"] = regionInfo?["res_version_config"]?["version"],
                        ["ReleaseTotalSize"] = regionInfo?["res_version_config"]?["release_total_size"]?.ToString() ?? "",
                        ["VersionSuffix"] = regionInfo?["res_version_config"]?["version_suffix"]?.ToString() ?? "",
                        ["Branch"] = regionInfo?["res_version_config"]?["branch"]?.ToString() ?? ""
                    }
                },
                ["StopServer"] = new JObject
                {
                    ["StopBeginTime"] = 1577808000,
                    ["StopEndTime"] = 1893427200,
                    ["Url"] = "https://vme50.icu/",
                    ["ContentMsg"] = "芜湖起飞"
                }
            };

            return newJson;
        }
    }
}
