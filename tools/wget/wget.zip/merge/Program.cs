﻿using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Linq;

public class Program
{
    public static void Main()
    {
        string inputPath = "input.txt";
        string infoDataVersionsPath = "info_data_versions.json";

        var infoDataVersions = JsonConvert.DeserializeObject<Dictionary<string, Dictionary<string, string>>>(File.ReadAllText(infoDataVersionsPath));

        Dictionary<string, object> versionTemplate = new Dictionary<string, object>();

        foreach (var version in infoDataVersions)
        {
            if (!version.Value.TryGetValue("Version_Suffix_client", out var clientValue) ||
                !version.Value.TryGetValue("Version_Suffix_silence", out var silenceValue))
                continue;

            // Extract values from info_data_versions.json
            var versionSuffixClient = clientValue.Split('_');
            var versionSuffixSilence = silenceValue.Split('_');

            versionTemplate["client"] = int.Parse(versionSuffixClient[0]);
            versionTemplate["client_silence"] = int.Parse(versionSuffixSilence[0]);
            versionTemplate["client_version_suffix"] = versionSuffixClient[1];
            versionTemplate["client_silence_version_suffix"] = versionSuffixSilence[1];

            foreach (var line in File.ReadAllLines(inputPath))
            {
                var lineParts = line.Split('|');
                if (lineParts.Length != 4) continue;

                var versionNumber = lineParts[0];
                var type = lineParts[1];
                var md5 = lineParts[2];
                var fileSize = lineParts[3];

                if (versionNumber == version.Key)
                {
                    var dataMd5 = new JObject
                    {
                        { "remoteName", "data_versions" },
                        { "md5", md5 },
                        { "fileSize", fileSize }
                    };

                    versionTemplate[$"{type}_data_md5"] = dataMd5.ToString(Formatting.None);
                }
            }

            // Create directory for the version
            var versionDir = $"output/{version.Key}";
            if (!Directory.Exists(versionDir))
                Directory.CreateDirectory(versionDir);

            // Save the organized output for each version in a single line
            File.WriteAllText(Path.Combine(versionDir, "version.txt"), JsonConvert.SerializeObject(versionTemplate, Formatting.None));
        }

        Console.WriteLine("Files and directories generated successfully!");
    }
}
