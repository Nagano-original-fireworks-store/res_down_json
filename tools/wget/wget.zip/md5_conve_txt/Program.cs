﻿using System;
using System.IO;
using System.Text.Json;
using System.Linq;

namespace Md5Converter
{
    class Program
    {
        public class Md5Info
        {
            public string? remoteName { get; set; }
            public string? md5 { get; set; }
            public int? fileSize { get; set; }
        }

        static void Main(string[] args)
        {
            // Hardcoded file paths for source and destination
            string sourcePath = "./input";  // Replace with your source directory path
            string destinationPath = "./output";  // Replace with your destination directory path

            // Check and create directories if they do not exist
            if (!Directory.Exists(sourcePath))
            {
                Directory.CreateDirectory(sourcePath);
            }
            if (!Directory.Exists(destinationPath))
            {
                Directory.CreateDirectory(destinationPath);
            }

            var jsonOptions = new JsonSerializerOptions
            {
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            };

            foreach (var file in Directory.GetFiles(sourcePath, "*.json"))
            {
                Console.WriteLine($"Processing file: {file}");

                // Read the content of the file
                var content = File.ReadAllText(file);
                var md5List = JsonSerializer.Deserialize<Md5Info[]>(content);

                // Extract branch information from the filename
                var branch = ExtractBranchFromFilename(Path.GetFileName(file));

                // Convert the content based on the given rules
                var convertedContent = ConvertMd5Content(md5List);

                // Create the final structure
                var finalContent = new
                {
                    version = "PLACEHOLDER_FOR_VERSION",
                    md5 = convertedContent,
                    releaseTotalSize = "0",
                    versionSuffix = "PLACEHOLDER_FOR_VERSION_SUFFIX",
                    branch
                };

                // Save the converted content to the destination path with .txt extension
                var destinationFile = Path.Combine(destinationPath, Path.GetFileNameWithoutExtension(file) + ".txt");
                File.WriteAllText(destinationFile, JsonSerializer.Serialize(finalContent, jsonOptions));
            }

            Console.WriteLine("Conversion completed!");
        }

        static string ConvertMd5Content(Md5Info[]? md5List)
        {
            if (md5List == null)
            {
                return "";
            }

            return string.Join("\n", md5List.Select(item =>
                $"{{\"remoteName\": \"{item.remoteName?.Replace(".txt", "")}\", \"md5\": \"{item.md5}\", \"fileSize\": {item.fileSize}}}"
            ));
        }

        static string ExtractBranchFromFilename(string filename)
        {
            var parts = filename.Split('_');
            if (parts.Length >= 3)
            {
                return parts[2].Replace(".json", "") + "_live";
            }
            return "unknown_live";
        }
    }
}
